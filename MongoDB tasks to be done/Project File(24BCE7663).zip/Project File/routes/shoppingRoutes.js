const express = require("express");
const router = express.Router();

const {
  getShoppingList,
  addShoppingItem,
  moveToFridge,
  deleteShoppingItem,
  clearMovedItems,
} = require("../controllers/shoppingController");

router.delete("/clear-moved", clearMovedItems);
router.get("/", getShoppingList);                       
router.post("/", addShoppingItem);                      
router.post("/move-to-fridge/:id", moveToFridge);      
router.delete("/:id", deleteShoppingItem);              

module.exports = router;
