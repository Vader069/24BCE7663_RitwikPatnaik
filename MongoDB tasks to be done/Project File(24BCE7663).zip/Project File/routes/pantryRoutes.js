const express = require("express");
const router = express.Router();

const {
  getAllIngredients,
  getDangerZone,
  addIngredient,
  bulkAddIngredients,
  updateQuantity,
  updateIngredient,
  deleteIngredient,
  purgeSpoiled,
  upsertIngredient,
} = require("../controllers/pantryController");

router.get("/danger-zone", getDangerZone);              
router.post("/bulk", bulkAddIngredients);              
router.post("/upsert", upsertIngredient);               
router.delete("/purge-spoiled", purgeSpoiled);          


router.get("/", getAllIngredients);                     
router.post("/", addIngredient);                        

router.patch("/:id/quantity", updateQuantity);         
router.put("/:id", updateIngredient);                   
router.delete("/:id", deleteIngredient);                

module.exports = router;
