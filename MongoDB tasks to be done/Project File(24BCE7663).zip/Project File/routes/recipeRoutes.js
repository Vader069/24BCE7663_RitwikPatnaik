const express = require("express");
const router = express.Router();

const {
  getAllRecipes,
  getRecipeById,
  matchRecipes,
  markCooked,
  addRecipe,
  deleteRecipe,
} = require("../controllers/recipeController");

router.get("/match", matchRecipes);                     
router.get("/", getAllRecipes);                         
router.post("/", addRecipe);                            
router.get("/:id", getRecipeById);                     
router.post("/:id/cooked", markCooked);                
router.delete("/:id", deleteRecipe);                   

module.exports = router;
