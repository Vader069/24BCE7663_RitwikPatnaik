const mongoose = require("mongoose");

const shoppingItemSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Item name is required"],
      trim: true,
      lowercase: true,
    },
    quantity: {
      type: Number,
      required: [true, "Quantity is required"],
      min: [0.01, "Quantity must be greater than 0"],
    },
    unit: {
      type: String,
      required: [true, "Unit is required"],
      enum: {
        values: ["units", "kg", "g", "litre", "ml", "cups"],
        message: "Invalid unit",
      },
    },
    sourceRecipeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Recipe",
      default: null,
    },
    sourceRecipeName: {
      type: String,
      default: null,
    },
    movedToFridge: {
      type: Boolean,
      default: false,
    },
    fridgeExpiryDate: {
      type: Date,
      default: null,
    },
    addedOn: {
      type: Date,
      default: Date.now,
    },
    ttlExpireAt: {
      type: Date,
      default: () => new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // +30 days
    },
  },
  { timestamps: true }
);

shoppingItemSchema.index({ ttlExpireAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model("ShoppingItem", shoppingItemSchema);
