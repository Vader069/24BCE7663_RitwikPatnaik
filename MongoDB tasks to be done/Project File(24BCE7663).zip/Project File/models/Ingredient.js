const mongoose = require("mongoose");

//Describing the Collection Schema
const ingredientSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Ingredient name is required"],
      trim: true,
      lowercase: true, 
    },
    quantity: {
      type: Number,
      required: [true, "Quantity is required"],
      min: [0.01, "Quantity must be greater than 0"],
    },
    unit: {
      type: String,
      required: [true, "Unit is required"],
      enum: {
        values: ["units", "kg", "g", "litre", "ml", "cups"],
        message: "Unit must be one of: units, kg, g, litre, ml, cups",
      },
    },
    expiryDate: {
      type: Date,
      required: [true, "Expiry date is required"],
      validate: {
        validator: function (v) {
          // Allow today but not past dates
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          return v >= today;
        },
        message: "Expiry date cannot be in the past",
      },
    },
    category: {
      type: String,
      enum: {
        values: ["dairy", "vegetable", "fruit", "grain", "protein", "spice", "other"],
        message: "Invalid category",
      },
      default: "other",
    },
    addedOn: {
      type: Date,
      default: Date.now,
    },
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

ingredientSchema.virtual("daysLeft").get(function () {
  const msPerDay = 1000 * 60 * 60 * 24;
  return Math.ceil((this.expiryDate - Date.now()) / msPerDay);
});


ingredientSchema.virtual("status").get(function () {
  const days = this.daysLeft;
  if (days <= 2) return "red";
  if (days <= 5) return "yellow";
  return "green";
});

ingredientSchema.index({ expiryDate: 1 });
ingredientSchema.index({ name: 1 }, { unique: true });

module.exports = mongoose.model("Ingredient", ingredientSchema);
