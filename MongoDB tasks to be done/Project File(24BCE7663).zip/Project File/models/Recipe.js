const mongoose = require("mongoose");

const recipeIngredientSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
    },
    quantity: {
      type: Number,
      required: true,
      min: 0.01,
    },
    unit: {
      type: String,
      required: true,
      enum: ["units", "kg", "g", "litre", "ml", "cups"],
    },
    optional: {
      type: Boolean,
      default: false,
    },
  },
  { _id: false } 
);
const recipeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Recipe name is required"],
      unique: true,
      trim: true,
    },
    ingredients: {
      type: [recipeIngredientSchema],
      validate: {
        validator: (arr) => arr.length >= 1,
        message: "A recipe must have at least one ingredient",
      },
    },
    instructions: {
      type: [String],
      required: [true, "Instructions are required"],
      validate: {
        validator: (arr) => arr.length >= 1,
        message: "A recipe must have at least one instruction step",
      },
    },
    cookTime: {
      type: Number,         
      min: [1, "Cook time must be at least 1 minute"],
      default: 15,
    },
    servings: {
      type: Number,
      min: [1, "Servings must be at least 1"],
      default: 2,
    },
    tags: {
      type: [String],
      default: [],
    },
    imageUrl: {
      type: String,
      default: null,
    },
  },
  { timestamps: true }
);
recipeSchema.index({ name: "text", tags: "text" });

module.exports = mongoose.model("Recipe", recipeSchema);
