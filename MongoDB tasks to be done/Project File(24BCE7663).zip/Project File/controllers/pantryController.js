const Ingredient = require("../models/Ingredient");

//Expiry date tracker
const getDangerThresholds = () => {
  const now = new Date();
  const redLimit = new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000);
  const yellowLimit = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);
  return { now, redLimit, yellowLimit };
};

//Display Ingredients
const getAllIngredients = async (req, res) => {
  try {
    const filter = {};
    if (req.query.category) filter.category = req.query.category;

    const { yellowLimit } = getDangerThresholds();

    if (req.query.status === "danger") {
      filter.expiryDate = { $lte: yellowLimit };
    } else if (req.query.status === "safe") {
      filter.expiryDate = { $gt: yellowLimit };
    }

    const ingredients = await Ingredient.find(filter).sort({ expiryDate: 1 });

    res.json({
      success: true,
      count: ingredients.length,
      data: ingredients,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

//Expiring Soon Items list
const getDangerZone = async (req, res) => {
  try {
    const fiveDaysMs = 5 * 24 * 60 * 60 * 1000;
    const items = await Ingredient.find({
      $expr: {
        $lte: [
          { $subtract: ["$expiryDate", new Date()] },
          fiveDaysMs,
        ],
      },
    }).sort({ expiryDate: 1 });
    const { redLimit } = getDangerThresholds();
    const red = items.filter((i) => i.expiryDate <= redLimit);
    const yellow = items.filter((i) => i.expiryDate > redLimit);

    res.json({
      success: true,
      count: items.length,
      data: { red, yellow },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

//Insert new Entry
const addIngredient = async (req, res) => {
  try {
    const ingredient = await Ingredient.create(req.body);
    res.status(201).json({ success: true, data: ingredient });
  } catch (err) {
    if (err.name === "ValidationError") {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    if (err.code === 11000) {
      return res.status(409).json({
        success: false,
        message: `"${req.body.name}" already exists in your pantry. Use PATCH to update quantity.`,
      });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};
const bulkAddIngredients = async (req, res) => {
  try {
    const { items } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Request body must contain a non-empty `items` array",
      });
    }
    const result = await Ingredient.insertMany(items, {
      ordered: false,
      rawResult: true,
    });

    res.status(207).json({
      success: true,
      insertedCount: result.insertedCount,
      errors: result.mongoose?.validationErrors || [],
      data: result.insertedIds,
    });
  } catch (err) {
    if (err.name === "BulkWriteError" || err.code === 11000) {
      return res.status(207).json({
        success: true,
        insertedCount: err.result?.nInserted ?? 0,
        message: "Some items were skipped (duplicates or validation errors)",
        writeErrors: err.writeErrors?.map((e) => ({
          index: e.index,
          message: e.errmsg,
        })),
      });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

//Change the item quantity
const updateQuantity = async (req, res) => {
  try {
    const { delta } = req.body;

    if (delta === undefined || typeof delta !== "number") {
      return res.status(400).json({
        success: false,
        message: "Body must contain a numeric `delta` field (positive or negative)",
      });
    }
    const updated = await Ingredient.findByIdAndUpdate(
      req.params.id,
      { $inc: { quantity: delta } },
      { returnDocument: 'after', runValidators: true }
    );

    if (!updated) {
      return res.status(404).json({ success: false, message: "Ingredient not found" });
    }

    if (updated.quantity <= 0) {
      await Ingredient.findByIdAndDelete(req.params.id);
      return res.json({
        success: true,
        message: "Ingredient fully consumed and removed from pantry",
        data: null,
      });
    }

    res.json({ success: true, data: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

//Changes to the item
const updateIngredient = async (req, res) => {
  try {
    const updated = await Ingredient.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { returnDocument: 'after', runValidators: true, upsert: true }
    );

    res.json({ success: true, data: updated });
  } catch (err) {
    if (err.name === "ValidationError") {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

//Removing Items from the inventory
const deleteIngredient = async (req, res) => {
  try {
    const deleted = await Ingredient.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ success: false, message: "Ingredient not found" });
    }

    res.json({ success: true, message: `"${deleted.name}" removed from pantry`, data: deleted });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

//Removing Expired Items from the database
const purgeSpoiled = async (req, res) => {
  try {
    const result = await Ingredient.deleteMany({
      expiryDate: { $lt: new Date() },
    });

    res.json({
      success: true,
      message: `${result.deletedCount} spoiled item removed from pantry`,
      deletedCount: result.deletedCount,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

//Update or insert new entry
const upsertIngredient = async (req, res) => {
  try {
    const { name, quantity, expiryDate, unit, category } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: "`name` is required" });
    }
    const result = await Ingredient.findOneAndUpdate(
      { name: name.toLowerCase().trim() },
      {
        $inc: { quantity: quantity || 1 },
        $set: {
          expiryDate,
          unit: unit || "units",
          category: category || "other",
        },
        $setOnInsert: { addedOn: new Date() },
      },
      { upsert: true, returnDocument: 'after', runValidators: true }
    );

    res.status(result ? 200 : 201).json({ success: true, data: result });
  } catch (err) {
    if (err.name === "ValidationError") {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = {
  getAllIngredients,
  getDangerZone,
  addIngredient,
  bulkAddIngredients,
  updateQuantity,
  updateIngredient,
  deleteIngredient,
  purgeSpoiled,
  upsertIngredient,
};
