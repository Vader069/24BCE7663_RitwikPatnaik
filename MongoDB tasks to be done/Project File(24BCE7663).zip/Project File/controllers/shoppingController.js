const ShoppingItem = require("../models/ShoppingList");
const Ingredient = require("../models/Ingredient");

//Not so relevant
const getShoppingList = async (req, res) => {
  try {
    const items = await ShoppingItem.find({ movedToFridge: false }).populate("sourceRecipeId", "name").sort({ addedOn: -1 });
    res.json({ success: true, count: items.length, data: items });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};


const addShoppingItem = async (req, res) => {
  try {
    const item = await ShoppingItem.create(req.body);
    res.status(201).json({ success: true, data: item });
  } catch (err) {
    if (err.name === "ValidationError") {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};


const moveToFridge = async (req, res) => {
  const session = await ShoppingItem.startSession();
  session.startTransaction();

  try {
    const { expiryDate, quantity, unit, category } = req.body;

    if (!expiryDate) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({
        success: false,
        message: "`expiryDate` is required when moving an item to the fridge",
      });
    }

    const shoppingItem = await ShoppingItem.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          movedToFridge: true,
          fridgeExpiryDate: new Date(expiryDate),
        },
      },
      { returnDocument: 'after', session }
    );

    if (!shoppingItem) {
      await session.abortTransaction();
      session.endSession();
      return res.status(404).json({ success: false, message: "Shopping item not found" });
    }
    const ingredient = await Ingredient.findOneAndUpdate(
      { name: shoppingItem.name },
      {
        $inc: { quantity: quantity ?? shoppingItem.quantity },
        $set: {
          expiryDate: new Date(expiryDate),
          unit: unit ?? shoppingItem.unit,
          category: category ?? "other",
        },
        $setOnInsert: { addedOn: new Date() },
      },
      { upsert: true, returnDocument: 'after', runValidators: true, session }
    );

    await session.commitTransaction();
    session.endSession();

    res.json({
      success: true,
      message: `"${shoppingItem.name}" moved to fridge and added to pantry`,
      shoppingItem,
      ingredient,
    });
  } catch (err) {
    await session.abortTransaction();
    session.endSession();

    if (err.name === "ValidationError") {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

const deleteShoppingItem = async (req, res) => {
  try {
    const deleted = await ShoppingItem.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: "Shopping item not found" });
    }
    res.json({ success: true, message: `"${deleted.name}" removed from shopping list`, data: deleted });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const clearMovedItems = async (req, res) => {
  try {
    const result = await ShoppingItem.deleteMany({ movedToFridge: true });
    res.json({
      success: true,
      message: `${result.deletedCount} completed item(s) cleared from shopping list`,
      deletedCount: result.deletedCount,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = {
  getShoppingList,
  addShoppingItem,
  moveToFridge,
  deleteShoppingItem,
  clearMovedItems,
};
