const Recipe = require("../models/Recipe");
const Ingredient = require("../models/Ingredient");

const getAllRecipes = async (req, res) => {
  try {
    let query = {};
    if (req.query.search) {
      query.$text = { $search: req.query.search };
    }
    if (req.query.tag) {
      query.tags = req.query.tag;
    }

    const recipes = await Recipe.find(query).sort({ name: 1 });
    res.json({ success: true, count: recipes.length, data: recipes });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getRecipeById = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) {
      return res.status(404).json({ success: false, message: "Recipe not found" });
    }
    res.json({ success: true, data: recipe });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const matchRecipes = async (req, res) => {
  try {
    const now = new Date();
    const redLimit = new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000);
    const yellowLimit = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);
    const results = await Recipe.aggregate([
      { $unwind: "$ingredients" },
      {
        $lookup: {
          from: "ingredients",           
          let: { ingName: "$ingredients.name", isOptional: "$ingredients.optional" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$name", "$$ingName"] },
              },
            },
            { $project: { name: 1, expiryDate: 1, quantity: 1, _id: 0 } },
          ],
          as: "pantryMatch",
        },
      },
      {
        $addFields: {
          isAvailable: { $gt: [{ $size: "$pantryMatch" }, 0] },
          isRedMatch: {
            $and: [
              { $gt: [{ $size: "$pantryMatch" }, 0] },
              {
                $lte: [
                  { $arrayElemAt: ["$pantryMatch.expiryDate", 0] },
                  redLimit,
                ],
              },
            ],
          },
          isYellowMatch: {
            $and: [
              { $gt: [{ $size: "$pantryMatch" }, 0] },
              {
                $gt: [
                  { $arrayElemAt: ["$pantryMatch.expiryDate", 0] },
                  redLimit,
                ],
              },
              {
                $lte: [
                  { $arrayElemAt: ["$pantryMatch.expiryDate", 0] },
                  yellowLimit,
                ],
              },
            ],
          },
        },
      },
      {
        $group: {
          _id: "$_id",
          name: { $first: "$name" },
          cookTime: { $first: "$cookTime" },
          servings: { $first: "$servings" },
          tags: { $first: "$tags" },
          instructions: { $first: "$instructions" },
          allIngredients: {
            $push: {
              name: "$ingredients.name",
              quantity: "$ingredients.quantity",
              unit: "$ingredients.unit",
              optional: "$ingredients.optional",
              isAvailable: "$isAvailable",
              isRedMatch: "$isRedMatch",
              isYellowMatch: "$isYellowMatch",
            },
          },
          
          availableCount: {
            $sum: { $cond: ["$isAvailable", 1, 0] },
          },
          missingRequiredCount: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $eq: ["$ingredients.optional", false] },
                    { $eq: ["$isAvailable", false] },
                  ],
                },
                1,
                0,
              ],
            },
          },
          urgencyScore: {
            $sum: {
              $cond: [
                "$isRedMatch",
                3,
                { $cond: ["$isYellowMatch", 1, 0] },
              ],
            },
          },
          redCount: { $sum: { $cond: ["$isRedMatch", 1, 0] } },
          yellowCount: { $sum: { $cond: ["$isYellowMatch", 1, 0] } },
        },
      },

      { $match: { missingRequiredCount: 0, availableCount: { $gt: 0 } } },
      { $sort: { urgencyScore: -1, availableCount: -1 } },
      {
        $project: {
          name: 1,
          cookTime: 1,
          servings: 1,
          tags: 1,
          instructions: 1,
          allIngredients: 1,
          availableCount: 1,
          urgencyScore: 1,
          redCount: 1,
          yellowCount: 1,
        },
      },
    ]);

    res.json({
      success: true,
      count: results.length,
      message:
        results.length === 0
          ? "No cookable recipes found with current pantry. Try adding more ingredients!"
          : `${results.length} recipe(s) matched — sorted by urgency`,
      data: results,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const markCooked = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) {
      return res.status(404).json({ success: false, message: "Recipe not found" });
    }

    const updateResults = [];

    for (const ing of recipe.ingredients) {
      if (ing.optional) continue; 
      const updated = await Ingredient.findOneAndUpdate(
        { name: ing.name },
        { $inc: { quantity: -ing.quantity } },
        { returnDocument: 'after' }
      );

      if (updated) {
        if (updated.quantity <= 0) {
          await Ingredient.findByIdAndDelete(updated._id);
          updateResults.push({ name: ing.name, action: "removed (fully consumed)" });
        } else {
          updateResults.push({ name: ing.name, action: `quantity updated to ${updated.quantity}` });
        }
      } else {
        updateResults.push({ name: ing.name, action: "not found in pantry — skipped" });
      }
    }

    res.json({
      success: true,
      message: `Pantry updated after cooking "${recipe.name}"`,
      updates: updateResults,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const addRecipe = async (req, res) => {
  try {
    const recipe = await Recipe.create(req.body);
    res.status(201).json({ success: true, data: recipe });
  } catch (err) {
    if (err.name === "ValidationError") {
      const messages = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    if (err.code === 11000) {
      return res.status(409).json({ success: false, message: "A recipe with this name already exists" });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

const deleteRecipe = async (req, res) => {
  try {
    const deleted = await Recipe.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: "Recipe not found" });
    }
    res.json({ success: true, message: `Recipe "${deleted.name}" deleted` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = {
  getAllRecipes,
  getRecipeById,
  matchRecipes,
  markCooked,
  addRecipe,
  deleteRecipe,
};
