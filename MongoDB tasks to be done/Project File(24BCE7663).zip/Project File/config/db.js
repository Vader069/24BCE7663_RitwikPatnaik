const mongoose = require("mongoose");
/* MongoDB connector using mongoose */
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      // useNewUrlParser: true,
      // useUnifiedTopology: true,
    });

    console.log(`MongoDB connected: ${conn.connection.host}`);
    const db = conn.connection.db;
    await db.collection("shoppingitems").createIndex({ ttlExpireAt: 1 }, { expireAfterSeconds: 0 });
    console.log("TTL index confirmed on shoppingitems.ttlExpireAt");
  } catch (err) {
    console.error(` MongoDB connection error: ${err.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
