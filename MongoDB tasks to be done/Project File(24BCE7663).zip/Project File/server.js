require("dotenv").config();
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const conDB = require("./config/db");

//Routes 
const pantryroute = require("./routes/pantryRoutes");
const reciproute = require("./routes/recipeRoutes");
const shoproute = require("./routes/shoppingRoutes");

//Connector to MongoDB
conDB();
const app = express();


app.use(cors());                              // Allow React frontend If i want to connect
app.use(express.json());                      // Parse JSON bodies
app.use(express.urlencoded({ extended: false }));

//morgan logging the entries
if (process.env.NODE_ENV === "development") {
  app.use(morgan("dev"));
}

//API routing
app.use("/api/pantry", pantryroute);
app.use("/api/recipes", reciproute);
app.use("/api/shopping", shoproute);

//Just a status checker
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    message: "FridgeBuddy API is running well and good",
  });
});

// API
app.get("/", (req, res) => {
  res.json({
    name: "FridgeBuddy API",
    version: "1.0.0",
    endpoints: {
      health: "GET /api/health",
      pantry: {
        list: "GET /api/pantry",
        dangerZone: "GET /api/pantry/danger-zone",
        add: "POST /api/pantry",
        bulkAdd: "POST /api/pantry/bulk",
        upsert: "POST /api/pantry/upsert",
        updateQuantity: "PATCH /api/pantry/:id/quantity",
        update: "PUT /api/pantry/:id",
        delete: "DELETE /api/pantry/:id",
        purgeSpoiled: "DELETE /api/pantry/purge-spoiled",
      },
      recipes: {
        list: "GET /api/recipes",
        match: "GET /api/recipes/match",
        get: "GET /api/recipes/:id",
        add: "POST /api/recipes",
        markCooked: "POST /api/recipes/:id/cooked",
        delete: "DELETE /api/recipes/:id",
      },
      shopping: {
        list: "GET /api/shopping",
        add: "POST /api/shopping",
        moveToFridge: "POST /api/shopping/move-to-fridge/:id",
        delete: "DELETE /api/shopping/:id",
        clearMoved: "DELETE /api/shopping/clear-moved",
      },
    },
  });
});

//404 error handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

//Error Handling if there is an unhandled error
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || "Internal Server Error",
  });
});

//server running
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`FridgeBuddy API running at http://localhost:${PORT}`);
  console.log(`Full API map: http://localhost:${PORT}/`);
});
